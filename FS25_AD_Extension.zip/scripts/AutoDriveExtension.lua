--
-- FS25_AD_Extension v1.0.0.5
-- Werkstatt-Button (fest, rechts) + dynamische Slots (links davon) + Icon-Picker
-- Autor: LazyChilla | Lizenz: MIT
--
-- Bedienung:
--   Linksklick          = Fahre zu Ziel
--   Rechtsklick         = AD-Ziel setzen
--   SHIFT+Linksklick    = Dynamischen Button loeschen
--   + Button            = Icon-Picker oeffnen/schliessen
--

ADExtension = {}
ADExtension.modDirectory      = g_currentModDirectory
ADExtension.initialized       = false
-- Werkstatt (fest, wie v1.0.0.3)
ADExtension.workshopMarkerID  = -1
ADExtension.workshopButtonRef = nil
-- Dynamische Slots
ADExtension.slots             = {}    -- [{icon, markerID}]
ADExtension.buttonRefs        = {}
ADExtension.plusRef           = nil
-- Picker
ADExtension.pickerOpen        = false
ADExtension.pickerRefs        = {}
ADExtension.pickerOvs         = nil
-- Zustand
ADExtension.headerH           = 0
ADExtension.hudSelf           = nil
ADExtension.clickCooldown     = 0
ADExtension.pendingRefresh    = false

ADExtension.ICONS = {
    "silo","kalk","duenger","saatgut","getreidesack",
    "fabrik","tank","kuh","huhn","schwein","ziege","schaf","pferd",
    "lager","traktor","mahdrescher","anhaenger","wald",
    "biogas","windrad","solar","biene","fisch",
    "location","zahnrad",
}

-- ============================================================
--  AD-ENVIRONMENT
-- ============================================================
local adEnvCache = nil

local function findAutoDriveInListeners(vehicleType)
    if vehicleType == nil or vehicleType.eventListeners == nil then return nil end
    for _, listeners in pairs(vehicleType.eventListeners) do
        if type(listeners) == "table" then
            for _, obj in ipairs(listeners) do
                if type(obj) == "table" and obj.MODE_DRIVETO ~= nil and obj.loadMap ~= nil then
                    return obj
                end
            end
        end
    end
    return nil
end

local function getADEnv()
    if adEnvCache ~= nil then return adEnvCache end
    if g_vehicleTypeManager == nil or g_vehicleTypeManager.types == nil then return nil end
    for _, vehicleType in pairs(g_vehicleTypeManager.types) do
        local ad = findAutoDriveInListeners(vehicleType)
        if ad ~= nil then
            local env = getfenv(ad.loadMap)
            if env ~= nil and env.AutoDriveHud ~= nil and env.ADInputManager ~= nil then
                if env.AutoDrive == nil then env.AutoDrive = ad end
                adEnvCache = env
                return adEnvCache
            end
        end
    end
    return nil
end

-- ============================================================
--  PERSISTENZ
-- ============================================================
function ADExtension.getSettingsPath()
    local folder = getUserProfileAppPath() .. "modSettings/FS25_AD_Extension/"
    createFolder(folder)
    return folder .. "buttons_config.xml"
end

function ADExtension.saveSettings()
    local path    = ADExtension.getSettingsPath()
    local xmlFile = createXMLFile("ADExt_XML", path, "ADExtension")
    if xmlFile == nil then return end
    -- Werkstatt (fest)
    setXMLInt(xmlFile, "ADExtension.workshop#markerID", ADExtension.workshopMarkerID)
    -- Dynamische Slots
    setXMLInt(xmlFile, "ADExtension#slotCount", #ADExtension.slots)
    for i, slot in ipairs(ADExtension.slots) do
        local key = string.format("ADExtension.slot(%d)", i - 1)
        setXMLString(xmlFile, key .. "#icon",     slot.icon)
        setXMLInt(xmlFile,    key .. "#markerID", slot.markerID)
    end
    saveXMLFile(xmlFile)
    delete(xmlFile)
end

function ADExtension.loadSettings()
    local path = ADExtension.getSettingsPath()
    if not fileExists(path) then return end
    local xmlFile = loadXMLFile("ADExt_XML", path)
    if xmlFile == nil then return end
    -- Werkstatt
    local wsID = getXMLInt(xmlFile, "ADExtension.workshop#markerID")
    if wsID ~= nil then ADExtension.workshopMarkerID = wsID end
    -- Dynamische Slots
    local count = getXMLInt(xmlFile, "ADExtension#slotCount") or 0
    ADExtension.slots = {}
    for i = 0, count - 1 do
        local key  = string.format("ADExtension.slot(%d)", i)
        local icon = getXMLString(xmlFile, key .. "#icon") or "location"
        local mid  = getXMLInt(xmlFile,    key .. "#markerID") or -1
        table.insert(ADExtension.slots, {icon = icon, markerID = mid})
    end
    delete(xmlFile)
end

-- ============================================================
--  HILFSFUNKTIONEN
-- ============================================================
local function isHudVisible()
    local env = getADEnv()
    return env ~= nil
        and env.AutoDrive ~= nil
        and env.AutoDrive.Hud ~= nil
        and g_lastMousePosX ~= nil
        and g_inputBinding ~= nil
        and g_inputBinding:getShowMouseCursor()
        and (env.AutoDrive.pullDownListExpanded == nil or env.AutoDrive.pullDownListExpanded == 0)
        and env.AutoDrive.Hud:isMouseOverHud(g_lastMousePosX, g_lastMousePosY) == true
end

local function getButtonY(self2)
    local extra = 0
    if self2.headerRef ~= nil and self2.headerRef.lastLineCount ~= nil then
        extra = self2.headerRef.lastLineCount - 1
    end
    return self2.baseY + extra * self2.lineHeight
end

function ADExtension.getWorkshopMarkerName()
    if ADExtension.workshopMarkerID < 1 then return nil end
    local env = getADEnv()
    if env == nil then return nil end
    local marker = env.ADGraphManager:getMapMarkerById(ADExtension.workshopMarkerID)
    if marker == nil then
        ADExtension.workshopMarkerID = -1
        ADExtension.saveSettings()
        return nil
    end
    return marker.name
end

function ADExtension.getSlotMarkerName(slotIdx)
    local slot = ADExtension.slots[slotIdx]
    if slot == nil or slot.markerID < 1 then return nil end
    local env = getADEnv()
    if env == nil then return nil end
    local marker = env.ADGraphManager:getMapMarkerById(slot.markerID)
    if marker == nil then
        slot.markerID = -1
        ADExtension.saveSettings()
        return nil
    end
    return marker.name
end

-- ============================================================
--  AKTIONEN WERKSTATT (unveraendert aus v1.0.0.3)
-- ============================================================
function ADExtension.setWorkshopDestination(vehicle)
    if vehicle == nil or vehicle.ad == nil then return end
    local env = getADEnv()
    if env == nil then return end
    local markerID = vehicle.ad.stateModule:getFirstMarkerId()
    if markerID == nil or markerID <= 0 then
        env.AutoDriveMessageEvent.sendMessageOrNotification(
            vehicle, env.ADMessagesManager.messageTypes.ERROR,
            g_i18n:getText("ADExt_noPosSet"), 5000,
            vehicle.ad.stateModule:getName()
        )
        return
    end
    local mapMarker = env.ADGraphManager:getMapMarkerById(markerID)
    if mapMarker == nil or mapMarker.isADDebug == true then return end
    ADExtension.workshopMarkerID = markerID
    ADExtension.saveSettings()
    local msg = g_i18n:getText("ADExt_selected") .. mapMarker.name
    env.ADMessagesManager:addMessage(vehicle, env.ADMessagesManager.messageTypes.INFO, msg, 5000)
end

function ADExtension.driveToWorkshop(vehicle, farmId)
    if vehicle == nil or vehicle.ad == nil then return end
    local env = getADEnv()
    if env == nil then return end
    if ADExtension.getWorkshopMarkerName() == nil then
        env.AutoDriveMessageEvent.sendMessageOrNotification(
            vehicle, env.ADMessagesManager.messageTypes.ERROR,
            g_i18n:getText("ADExt_noPosSet"), 5000,
            vehicle.ad.stateModule:getName()
        )
        return
    end
    vehicle.ad.stateModule:setFirstMarker(ADExtension.workshopMarkerID)
    env.AutoDrive:StopCP(vehicle)
    if vehicle.ad.stateModule:isActive() then
        env.ADInputManager:input_start_stop(vehicle, farmId)
    end
    vehicle.ad.stateModule:setMode(env.AutoDrive.MODE_DRIVETO)
    env.ADInputManager:input_start_stop(vehicle, farmId)
end

-- ============================================================
--  AKTIONEN DYNAMISCHE SLOTS
-- ============================================================
function ADExtension.setSlotDestination(vehicle, slotIdx)
    if vehicle == nil or vehicle.ad == nil then return end
    local env  = getADEnv()
    if env == nil then return end
    local slot = ADExtension.slots[slotIdx]
    if slot == nil then return end
    local markerID = vehicle.ad.stateModule:getFirstMarkerId()
    if markerID == nil or markerID <= 0 then
        env.AutoDriveMessageEvent.sendMessageOrNotification(
            vehicle, env.ADMessagesManager.messageTypes.ERROR,
            g_i18n:getText("ADExt_noPosSet"), 5000,
            vehicle.ad.stateModule:getName()
        )
        return
    end
    local mapMarker = env.ADGraphManager:getMapMarkerById(markerID)
    if mapMarker == nil or mapMarker.isADDebug == true then return end
    slot.markerID = markerID
    ADExtension.saveSettings()
    local msg = slot.icon .. ": " .. g_i18n:getText("ADExt_selected") .. mapMarker.name
    env.ADMessagesManager:addMessage(vehicle, env.ADMessagesManager.messageTypes.INFO, msg, 5000)
end

function ADExtension.driveToSlot(vehicle, farmId, slotIdx)
    if vehicle == nil or vehicle.ad == nil then return end
    local env  = getADEnv()
    if env == nil then return end
    local slot = ADExtension.slots[slotIdx]
    if slot == nil then return end
    if ADExtension.getSlotMarkerName(slotIdx) == nil then
        env.AutoDriveMessageEvent.sendMessageOrNotification(
            vehicle, env.ADMessagesManager.messageTypes.ERROR,
            g_i18n:getText("ADExt_noPosSet"), 5000,
            vehicle.ad.stateModule:getName()
        )
        return
    end
    vehicle.ad.stateModule:setFirstMarker(slot.markerID)
    env.AutoDrive:StopCP(vehicle)
    if vehicle.ad.stateModule:isActive() then
        env.ADInputManager:input_start_stop(vehicle, farmId)
    end
    vehicle.ad.stateModule:setMode(env.AutoDrive.MODE_DRIVETO)
    env.ADInputManager:input_start_stop(vehicle, farmId)
end

-- ============================================================
--  SLOT VERWALTUNG
-- ============================================================
function ADExtension.addSlot(iconName)
    table.insert(ADExtension.slots, {icon = iconName, markerID = -1})
    ADExtension.saveSettings()
    ADExtension.pickerOpen     = false
    ADExtension.pendingRefresh = true
end

function ADExtension.removeSlot(slotIdx)
    table.remove(ADExtension.slots, slotIdx)
    ADExtension.saveSettings()
    ADExtension.pendingRefresh = true
end

-- ============================================================
--  PICKER OVERLAYS (lazy)
-- ============================================================
function ADExtension.loadPickerOverlays(btnW, btnH)
    if ADExtension.pickerOvs ~= nil then return end
    ADExtension.pickerOvs = {}
    for _, name in ipairs(ADExtension.ICONS) do
        local path = ADExtension.modDirectory .. "textures/icons/" .. name .. ".dds"
        if fileExists(path) then
            ADExtension.pickerOvs[name] = Overlay.new(path, 0, 0, btnW, btnH)
        end
    end
end

-- ============================================================
--  HUD-ELEMENTE AUFBAUEN
-- ============================================================
function ADExtension.refreshHudButtons()
    local hudSelf = ADExtension.hudSelf
    if hudSelf == nil then return end

    -- Alte ADExt-Elemente entfernen (ausser Werkstatt-Button)
    for i = #hudSelf.hudElements, 1, -1 do
        if hudSelf.hudElements[i].isADExt then
            table.remove(hudSelf.hudElements, i)
        end
    end
    ADExtension.buttonRefs     = {}
    ADExtension.plusRef        = nil
    ADExtension.pickerRefs     = {}

    local env = getADEnv()
    if env == nil then return end
    local AutoDrive = env.AutoDrive

    local btnW   = hudSelf.buttonWidth
    local btnH   = hudSelf.buttonHeight
    local gapW   = hudSelf.gapWidth
    local gapH   = hudSelf.gapHeight
    local baseY  = hudSelf.rowHeader + hudSelf.headerHeight + gapH
    local rightX = hudSelf.posX + hudSelf.width
    local perRow = math.max(1, math.floor((hudSelf.width + gapW) / (btnW + gapW)))

    local uiScale = g_gameSettings:getValue("uiScale")
    if AutoDrive.getSetting("guiScale") ~= 0 then uiScale = AutoDrive.getSetting("guiScale") end
    local lineH = getTextHeight(0.011 * uiScale, "text") + gapH

    -- Für draw() speichern
    ADExtension.btnH_norm     = btnH
    ADExtension.gapH_norm     = gapH
    ADExtension.numPickerRows = 0
    ADExtension.numSlotRows   = 1

    local headerRef = nil
    for _, el in ipairs(hudSelf.hudElements) do
        if el.name == "header" then headerRef = el; break end
    end

    -- ---- WERKSTATT BUTTON (fest, Position 1 = ganz rechts) ----
    local wsX      = rightX - btnW
    local wsPath   = ADExtension.modDirectory .. "textures/icons/workshop.dds"
    local wsActive = Overlay.new(wsPath, wsX, baseY, btnW, btnH)
    local wsBtn    = {
        isADExt    = true,
        isWorkshop = true,
        position   = {x = wsX, y = baseY},
        size       = {width = btnW, height = btnH},
        isVisible  = false,
        overlay    = wsActive,
        baseY      = baseY,
        headerRef  = headerRef,
        lineHeight = lineH,
        layer      = 0,
    }
    wsBtn.update = function(self2, dt) end
    wsBtn.hit = function(self2, x, y, z)
        return x >= self2.position.x and x <= self2.position.x + self2.size.width
           and y >= self2.position.y and y <= self2.position.y + self2.size.height
    end
    wsBtn.onDraw = function(self2, vehicle2, uiScale2)
        local y = getButtonY(self2)
        self2.position.y = y
        self2.isVisible  = isHudVisible()
        if not self2.isVisible then return end
        local alpha = (ADExtension.getWorkshopMarkerName() ~= nil) and 1.0 or 0.2
        self2.overlay:setColor(1, 1, 1, alpha)
        self2.overlay:setPosition(self2.position.x, y)
        self2.overlay:render()
    end
    wsBtn.mouseEvent = function(self2, vehicle2, posX2, posY2, isDown, isUp, button, layer)
        if not self2.isVisible then return false end
        if ADExtension.pickerOpen then return false end
        local px, py = self2.position.x, self2.position.y
        if posX2 >= px and posX2 <= px + self2.size.width
           and posY2 >= py and posY2 <= py + self2.size.height then
            vehicle2.ad.sToolTip         = ""
            vehicle2.ad.nToolTipWait     = 5
            vehicle2.ad.sToolTipInfo     = g_i18n:getText("ADExt_name_workshop")
            vehicle2.ad.toolTipIsSetting = false
            if isDown and button == 1 then return true end
            if isUp and button == 1
                and not AutoDrive.leftLSHIFTmodifierKeyPressed
                and not AutoDrive.leftCTRLmodifierKeyPressed then
                local farmId = (AutoDrive.getPlayer() ~= nil and AutoDrive.getPlayer().farmId) or 0
                ADExtInputEvent.sendEvent(vehicle2, 1, farmId, 0)
                return true
            end
            if isUp and (button == 3 or button == 2) then
                local farmId = (AutoDrive.getPlayer() ~= nil and AutoDrive.getPlayer().farmId) or 0
                ADExtInputEvent.sendEvent(vehicle2, 2, farmId, 0)
                return true
            end
        end
        return false
    end
    table.insert(hudSelf.hudElements, wsBtn)
    ADExtension.workshopButtonRef = wsBtn

    -- ---- DYNAMISCHE SLOT-BUTTONS (Grid, ab Position 1 = links von Workshop) ----
    for i, slot in ipairs(ADExtension.slots) do
        local slotCol   = i % perRow
        local slotRow   = math.floor(i / perRow)
        local bX        = rightX - (slotCol + 1) * (btnW + gapW) + gapW
        local slotBaseY = baseY + slotRow * (btnH + gapH)
        local iconPath  = ADExtension.modDirectory .. "textures/icons/" .. slot.icon .. ".dds"
        local ov        = Overlay.new(iconPath, bX, slotBaseY, btnW, btnH)
        local btn = {
            isADExt    = true,
            slotIdx    = i,
            position   = {x = bX, y = slotBaseY},
            size       = {width = btnW, height = btnH},
            isVisible  = false,
            overlay    = ov,
            baseY      = slotBaseY,
            headerRef  = headerRef,
            lineHeight = lineH,
            layer      = 0,
        }
        btn.update = function(self2, dt) end
        btn.hit = function(self2, x, y, z)
            return x >= self2.position.x and x <= self2.position.x + self2.size.width
               and y >= self2.position.y and y <= self2.position.y + self2.size.height
        end
        btn.onDraw = function(self2, vehicle2, uiScale2)
            local y = getButtonY(self2)
            self2.position.y = y
            self2.isVisible  = isHudVisible()
            if not self2.isVisible then return end
            local alpha = (ADExtension.getSlotMarkerName(self2.slotIdx) ~= nil) and 1.0 or 0.2
            self2.overlay:setColor(1, 1, 1, alpha)
            self2.overlay:setPosition(self2.position.x, y)
            self2.overlay:render()
        end
        btn.mouseEvent = function(self2, vehicle2, posX2, posY2, isDown, isUp, button, layer)
            if not self2.isVisible then return false end
            if ADExtension.pickerOpen then return false end
            local px, py = self2.position.x, self2.position.y
            if posX2 >= px and posX2 <= px + self2.size.width
               and posY2 >= py and posY2 <= py + self2.size.height then
                vehicle2.ad.sToolTip         = ""
                vehicle2.ad.nToolTipWait     = 5
                vehicle2.ad.sToolTipInfo     = ADExtension.slots[self2.slotIdx] ~= nil
                    and ADExtension.slots[self2.slotIdx].icon or ""
                vehicle2.ad.toolTipIsSetting = false
                if isDown and button == 1 then return true end
                if isUp and button == 1 and AutoDrive.leftLSHIFTmodifierKeyPressed then
                    if g_currentMission.time > ADExtension.clickCooldown then
                        ADExtension.clickCooldown = g_currentMission.time + 400
                        ADExtension.removeSlot(self2.slotIdx)
                    end
                    return true
                end
                if isUp and button == 1
                    and not AutoDrive.leftLSHIFTmodifierKeyPressed
                    and not AutoDrive.leftCTRLmodifierKeyPressed then
                    local farmId = (AutoDrive.getPlayer() ~= nil and AutoDrive.getPlayer().farmId) or 0
                    ADExtInputEvent.sendEvent(vehicle2, 1, farmId, self2.slotIdx)
                    return true
                end
                if isUp and (button == 3 or button == 2) then
                    local farmId = (AutoDrive.getPlayer() ~= nil and AutoDrive.getPlayer().farmId) or 0
                    ADExtInputEvent.sendEvent(vehicle2, 2, farmId, self2.slotIdx)
                    return true
                end
            end
            return false
        end
        table.insert(hudSelf.hudElements, btn)
        ADExtension.buttonRefs[i] = btn
    end

    -- ---- PLUS BUTTON (folgt dem letzten Slot im Grid) ----
    local nSlots    = #ADExtension.slots
    local plusGrid  = nSlots + 1
    local plusCol   = plusGrid % perRow
    local plusRow   = math.floor(plusGrid / perRow)
    local plusW     = btnW * 0.7
    local plusH     = btnH * 0.7
    local plusX     = rightX - (plusCol + 1) * (btnW + gapW) + gapW + (btnW - plusW) * 0.5
    local plusBaseY = baseY + plusRow * (btnH + gapH) + (btnH - plusH) * 0.5

    -- Anzahl Button-Zeilen für draw() merken
    ADExtension.numSlotRows = plusRow + 1

    local plusPath = ADExtension.modDirectory .. "textures/icons/plus.dds"
    local plusOv   = Overlay.new(plusPath, plusX, plusBaseY, plusW, plusH)
    local plusBtn  = {
        isADExt    = true,
        isPlusBtn  = true,
        position   = {x = plusX, y = plusBaseY},
        size       = {width = plusW, height = plusH},
        isVisible  = false,
        overlay    = plusOv,
        baseY      = plusBaseY,
        headerRef  = headerRef,
        lineHeight = lineH,
        layer      = 0,
    }
    plusBtn.update = function(self2, dt) end
    plusBtn.hit = function(self2, x, y, z)
        return x >= self2.position.x and x <= self2.position.x + self2.size.width
           and y >= self2.position.y and y <= self2.position.y + self2.size.height
    end
    plusBtn.onDraw = function(self2, vehicle2, uiScale2)
        local y = getButtonY(self2)
        self2.position.y = y
        self2.isVisible  = isHudVisible()
        if not self2.isVisible then return end
        self2.overlay:setColor(1, 1, 1, ADExtension.pickerOpen and 1.0 or 0.5)
        self2.overlay:setPosition(self2.position.x, y)
        self2.overlay:render()
    end
    plusBtn.mouseEvent = function(self2, vehicle2, posX2, posY2, isDown, isUp, button, layer)
        if not self2.isVisible then return false end
        local px, py = self2.position.x, self2.position.y
        if posX2 >= px and posX2 <= px + self2.size.width
           and posY2 >= py and posY2 <= py + self2.size.height then
            if isDown and button == 1 then return true end
            if isUp and button == 1 then
                if g_currentMission.time > ADExtension.clickCooldown then
                    ADExtension.clickCooldown  = g_currentMission.time + 400
                    ADExtension.pickerOpen     = not ADExtension.pickerOpen
                    ADExtension.pendingRefresh = true
                end
                return true
            end
        end
        return false
    end
    table.insert(hudSelf.hudElements, plusBtn)
    ADExtension.plusRef = plusBtn

    -- ---- PICKER ICONS (falls offen, UEBER der Button-Reihe) ----
    if ADExtension.pickerOpen then
        ADExtension.loadPickerOverlays(btnW, btnH)
        local perRow = math.max(1, math.floor((hudSelf.width + gapW) / (btnW + gapW)))
        local col = 0
        local row = 0
        for _, name in ipairs(ADExtension.ICONS) do
            local ov = ADExtension.pickerOvs ~= nil and ADExtension.pickerOvs[name] or nil
            if ov ~= nil then
                local bX     = rightX - (col + 1) * (btnW + gapW) + gapW
                local rowOff = (row + 1) * (btnH + gapH)
                local pName  = name
                local pBtn   = {
                    isADExt    = true,
                    isPickerEl = true,
                    iconName   = pName,
                    position   = {x = bX, y = baseY + rowOff},
                    size       = {width = btnW, height = btnH},
                    isVisible  = false,
                    overlay    = ov,
                    baseY      = baseY,
                    rowOff     = rowOff,
                    headerRef  = headerRef,
                    lineHeight = lineH,
                    layer      = 0,
                }
                pBtn.update = function(self2, dt) end
                pBtn.hit = function(self2, x, y, z)
                    return x >= self2.position.x and x <= self2.position.x + self2.size.width
                       and y >= self2.position.y and y <= self2.position.y + self2.size.height
                end
                pBtn.onDraw = function(self2, vehicle2, uiScale2)
                    local y = getButtonY(self2) + self2.rowOff
                    self2.position.y = y
                    self2.isVisible  = isHudVisible() and ADExtension.pickerOpen
                    if not self2.isVisible then return end
                    self2.overlay:setColor(1, 1, 1, 0.85)
                    self2.overlay:setPosition(self2.position.x, y)
                    self2.overlay:render()
                end
                pBtn.mouseEvent = function(self2, vehicle2, posX2, posY2, isDown, isUp, button, layer)
                    if not self2.isVisible then return false end
                    local px, py = self2.position.x, self2.position.y
                    if posX2 >= px and posX2 <= px + self2.size.width
                       and posY2 >= py and posY2 <= py + self2.size.height then
                        if isDown and button == 1 then return true end
                        if isUp and button == 1 then
                            if g_currentMission.time > ADExtension.clickCooldown then
                                ADExtension.clickCooldown = g_currentMission.time + 400
                                ADExtension.addSlot(self2.iconName)
                            end
                            return true
                        end
                    end
                    return false
                end
                table.insert(hudSelf.hudElements, pBtn)
                table.insert(ADExtension.pickerRefs, pBtn)
                col = col + 1
                if col >= perRow then col = 0; row = row + 1 end
            end
        end
        ADExtension.numPickerRows = row + (col > 0 and 1 or 0)
    end

    if hudSelf.refreshHudElementsLayerSequence ~= nil then
        hudSelf:refreshHudElementsLayerSequence()
    end
end

-- ============================================================
--  HOOKS
-- ============================================================
function ADExtension.installHooks()
    if ADExtension.initialized then return end
    local env = getADEnv()
    if env == nil then
        Logging.error("[ADExt] AD-Environment nicht gefunden.")
        return
    end
    local AutoDrive      = env.AutoDrive
    local AutoDriveHud   = env.AutoDriveHud
    local ADInputManager = env.ADInputManager

    local originalCreateHudAt = AutoDriveHud.createHudAt
    AutoDriveHud.createHudAt = function(self, hudX, hudY)
        originalCreateHudAt(self, hudX, hudY)
        ADExtension.hudSelf = self
        ADExtension.headerH = self.headerHeight
        ADExtension.refreshHudButtons()
    end

    local originalOnActionCall = ADInputManager.onActionCall
    ADInputManager.onActionCall = function(vehicle2, actionName)
        if actionName == "ADExt_WorkshopVehicle" then
            local farmId = (AutoDrive.getPlayer() ~= nil and AutoDrive.getPlayer().farmId) or 0
            ADExtInputEvent.sendEvent(vehicle2, 1, farmId, 0)
            return
        end
        if actionName == "ADExt_SetWorkshopDestination" then
            local farmId = (AutoDrive.getPlayer() ~= nil and AutoDrive.getPlayer().farmId) or 0
            ADExtInputEvent.sendEvent(vehicle2, 2, farmId, 0)
            return
        end
        return originalOnActionCall(vehicle2, actionName)
    end

    ADExtension.initialized = true
end

-- ============================================================
--  EINSTIEGSPUNKT
-- ============================================================
if TypeManager ~= nil and TypeManager.validateTypes ~= nil then
    TypeManager.validateTypes = Utils.appendedFunction(
        TypeManager.validateTypes,
        function(self) end
    )
end

ADExtensionRegister = {}

function ADExtensionRegister:loadMap(name)
    if not ADExtension.initialized then
        if getADEnv() ~= nil then
            ADExtension.installHooks()
        else
            Logging.error("[ADExt] AutoDrive-Environment nicht gefunden.")
            return
        end
    end
    if ADExtension.initialized then
        ADExtension.loadSettings()
    end
end

function ADExtensionRegister:deleteMap()
    ADExtension.initialized    = false
    ADExtension.hudSelf        = nil
    ADExtension.workshopButtonRef = nil
    ADExtension.buttonRefs     = {}
    ADExtension.plusRef        = nil
    ADExtension.pickerRefs     = {}
    ADExtension.pickerOvs      = nil
    ADExtension.pickerOpen     = false
    ADExtension.pendingRefresh = false
    adEnvCache                 = nil
end

function ADExtensionRegister:update(dt)
    if ADExtension.pendingRefresh and ADExtension.initialized then
        ADExtension.pendingRefresh = false
        ADExtension.refreshHudButtons()
    end
end

function ADExtensionRegister:draw()
    if not ADExtension.initialized then return end
    local env = getADEnv()
    if env == nil or env.AutoDrive == nil or env.AutoDrive.Hud == nil then return end
    if env.AutoDrive.pullDownListExpanded ~= nil and env.AutoDrive.pullDownListExpanded > 0 then return end

    local wsBtn = ADExtension.workshopButtonRef
    if wsBtn == nil or not wsBtn.isVisible then return end

    local selfMod = g_modManager:getModByName("FS25_AD_Extension")
    local version = (selfMod ~= nil and selfMod.version ~= nil) and selfMod.version or "1.1.0.1"
    local fontSize = ADExtension.headerH * 0.55
    local textX    = wsBtn.position.x - fontSize * 0.3
    -- Eine Zeile über der obersten aktiven Icon-Reihe (Slot-Reihen + Picker-Reihen)
    local totalRows = (ADExtension.numSlotRows or 1)
        + (ADExtension.pickerOpen and (ADExtension.numPickerRows or 0) or 0)
    local textY = wsBtn.position.y + totalRows * (ADExtension.btnH_norm + ADExtension.gapH_norm)

    setTextBold(false)
    setTextAlignment(RenderText.ALIGN_RIGHT)
    setTextColor(0.9, 0.9, 0.9, 0.85)
    renderText(textX, textY, fontSize, "AD Extension v" .. version)
    setTextAlignment(RenderText.ALIGN_LEFT)
    setTextColor(1, 1, 1, 1)
    setTextBold(false)

    if ADExtension.pickerOpen then
        setTextAlignment(RenderText.ALIGN_RIGHT)
        setTextColor(0.9, 0.85, 0.4, 0.9)
        renderText(textX, textY + fontSize * 1.3, fontSize * 0.85, "SHIFT+Klick = loeschen")
        setTextAlignment(RenderText.ALIGN_LEFT)
        setTextColor(1, 1, 1, 1)
    end
end

ItemSystem.save = Utils.appendedFunction(ItemSystem.save, function()
    if ADExtension.initialized then ADExtension.saveSettings() end
end)

addModEventListener(ADExtensionRegister)

Logging.info("[ADExt] FS25_AD_Extension v1.1.0.1 geladen.")
