--
-- ADExtInputEvent.lua (v1.0.0.5)
-- slotIdx = 0  -> Werkstatt (fest)
-- slotIdx > 0  -> Dynamischer Slot
--

ADExtInputEvent = {}
ADExtInputEvent_mt = Class(ADExtInputEvent, Event)
InitEventClass(ADExtInputEvent, "ADExtInputEvent")

function ADExtInputEvent.emptyNew()
    local self = Event.new(ADExtInputEvent_mt)
    return self
end

function ADExtInputEvent.new(vehicle, actionType, farmId, slotIdx)
    local self      = ADExtInputEvent.emptyNew()
    self.vehicle    = vehicle
    self.actionType = actionType
    self.farmId     = farmId
    self.slotIdx    = slotIdx or 0
    return self
end

function ADExtInputEvent:writeStream(streamId, connection)
    NetworkUtil.writeNodeObjectId(streamId, NetworkUtil.getObjectId(self.vehicle))
    streamWriteUInt8(streamId, self.actionType)
    streamWriteUInt8(streamId, self.farmId)
    streamWriteUInt8(streamId, self.slotIdx)
end

function ADExtInputEvent:readStream(streamId, connection)
    self.vehicle    = NetworkUtil.getObject(NetworkUtil.readNodeObjectId(streamId))
    self.actionType = streamReadUInt8(streamId)
    self.farmId     = streamReadUInt8(streamId)
    self.slotIdx    = streamReadUInt8(streamId)
    self:run(connection)
end

function ADExtInputEvent:run(connection)
    if g_server ~= nil and self.vehicle ~= nil then
        if self.slotIdx == 0 then
            -- Werkstatt
            if self.actionType == 1 then
                ADExtension.driveToWorkshop(self.vehicle, self.farmId)
            elseif self.actionType == 2 then
                ADExtension.setWorkshopDestination(self.vehicle)
            end
        else
            -- Dynamischer Slot
            if self.actionType == 1 then
                ADExtension.driveToSlot(self.vehicle, self.farmId, self.slotIdx)
            elseif self.actionType == 2 then
                ADExtension.setSlotDestination(self.vehicle, self.slotIdx)
            end
        end
    end
end

function ADExtInputEvent.sendEvent(vehicle, actionType, farmId, slotIdx)
    local idx = slotIdx or 0
    if g_server ~= nil then
        if idx == 0 then
            if actionType == 1 then
                ADExtension.driveToWorkshop(vehicle, farmId)
            elseif actionType == 2 then
                ADExtension.setWorkshopDestination(vehicle)
            end
        else
            if actionType == 1 then
                ADExtension.driveToSlot(vehicle, farmId, idx)
            elseif actionType == 2 then
                ADExtension.setSlotDestination(vehicle, idx)
            end
        end
    elseif g_client ~= nil then
        g_client:getServerConnection():sendEvent(
            ADExtInputEvent.new(vehicle, actionType, farmId, idx))
    end
end
